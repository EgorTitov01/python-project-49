### Hexlet tests and linter status:
[![Actions Status](https://github.com/EgorTitov01/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/EgorTitov01/python-project-49/actions)https://asciinema.org/a/1EqFN2Mh2jdIalHMzNfxLYyav
