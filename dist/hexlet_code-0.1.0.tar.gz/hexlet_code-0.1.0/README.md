### Hexlet tests and linter status:
[![Actions Status](https://github.com/EgorTitov01/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/EgorTitov01/python-project-49/actions)

1)brain-even - https://asciinema.org/a/eneihHL7eovJSnOx6osgD84ng
2)brain calc - https://asciinema.org/a/vYsL4kZbDVatgPyqagW3L2O7P
3)brain-gcd - https://asciinema.org/a/prV53zWpb31mVf4w4kHWt5TQi
