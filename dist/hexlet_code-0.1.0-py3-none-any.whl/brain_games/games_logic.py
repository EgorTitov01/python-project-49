import prompt


def start_game(game):

    print('Welcome to the Brain Games!\nMay I have your name?')
    name = prompt.string('')
    print(f'Hello, {name}!')
    count = 0

    while count < 3:

        question, right_answer = game()
        answer = prompt.string(question)

        if right_answer == str(answer):
            print('Correct!')
            count += 1
        else:
            break

    if count == 3:
        print(f'Congratulations, {name}!')
    else:
        print(f"{answer} is wrong answer ;(. Correct answer was"
              f" {right_answer}. Let's try again, {name}!")
